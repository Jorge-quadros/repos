﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebFrases.DAL;

namespace WebFrases
{
    public partial class Autor : System.Web.UI.Page
    {
        private System.Configuration.ConnectionStringSettings connString;
        protected void Page_Load(object sender, EventArgs e)
        {
            AtualizaGrid();
        }

        public void AtualizaGrid()
        {
            DALAutor dal = new DALAutor();
            gvDados.DataSource = dal.Localizar();
            gvDados.DataBind();
        }

        private void LimparCampos()
        {
            txtID.Text = "";
            txtNome.Text = "";
            btSalvar.Text = "Inserir";
        }

        protected void gvDados_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt32(e.RowIndex);
            int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
            string caminho = Server.MapPath(@"imagens\Autores\");
            string msg = "";

            DALAutor dal = new DALAutor();
            ModeloAutor obj = new ModeloAutor();
            ModeloAutor uold = dal.GetRegistro(obj.Id);
                        
            if (uold.Foto != "")
            {
                
                File.Delete(caminho + uold.Foto);
            }

            ModeloAutor objConsulta = new ModeloAutor();
            SqlConnection Consulta = new SqlConnection();
            Consulta.ConnectionString = connString.ToString();
            SqlCommand CmdConsulta = new SqlCommand();

            System.Configuration.Configuration rootWebConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/MyWebSiteRoot");
            connString = rootWebConfig.ConnectionStrings.ConnectionStrings["sisfrases9ConnectionString"];
            CmdConsulta.Connection = Consulta;
            CmdConsulta.CommandText = "Select * from frases where autor=@autor";
            CmdConsulta.Parameters.AddWithValue("autor", cod.ToString());

            Consulta.Open();

            SqlDataReader registro = CmdConsulta.ExecuteReader();

            if (registro.HasRows == false)
            {
                dal.Excluir(cod);
            }
            else
            {
                msg = "<script> ShowMsg('Cadastro','Registro não pode ser excluido pois está vinculado em outras tabelas!!'); </script>";
                PlaceHolder1.Controls.Add(new LiteralControl(msg));
            }

            this.LimparCampos();
            AtualizaGrid();
        }

        protected void gvDados_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int index = gvDados.SelectedIndex;
                int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
                DALAutor dal = new DALAutor();
                ModeloAutor c = dal.GetRegistro(cod);
                if (c.Id != 0)
                {
                    txtID.Text = c.Id.ToString();
                    txtNome.Text = c.Nome;
                    btSalvar.Text = "Alterar";
                }
            }
            catch
            {

            }
        }

        protected void btCancelar_Click(object sender, EventArgs e)
        {
            this.LimparCampos();
        }

        protected void btSalvar_Click(object sender, EventArgs e)
        {
            String msg = "";
            String caminho = Server.MapPath(@"imagens\Autores\");
            
            DALAutor dal = new DALAutor();
            ModeloAutor obj = new ModeloAutor();
            obj.Nome = txtNome.Text;
            
            //faz o upload da foto e salva o nome no obj
            if (Foto.PostedFile.FileName != "")
            {
                obj.Foto = DateTime.Now.Millisecond.ToString() + Foto.PostedFile.FileName;
                String img = caminho + obj.Foto;
                Foto.PostedFile.SaveAs(img);
            }
            try
            {
                if (btSalvar.Text == "Inserir")
                {

                    //Acessa o objeto DAL e Inseri os dados no Banco de Dados
                    dal.Inserir(obj);
                    msg = "<script> ShowMsg('Cadastro','O código gerado foi: " + obj.Id.ToString() + "'); </script>";
                    PlaceHolder1.Controls.Add(new LiteralControl(msg));
                }
                else
                {

                    //Acessa o objeto DAL e Altera os dados no Banco de Dados
                    obj.Id = Convert.ToInt32(txtID.Text);
                    //verificar se existe foto e deletar
                    ModeloAutor uold = dal.GetRegistro(obj.Id);
                    if (uold.Foto != "")
                    {
                        File.Delete(caminho + uold.Foto);
                    }
                    
                    dal.Alterar(obj);
                    msg = "<script> ShowMsg('Cadastro','Registro alterado corretamente!!!!'); </script>";
                    PlaceHolder1.Controls.Add(new LiteralControl(msg));

                }

                PlaceHolder1.Controls.Add(new LiteralControl(msg));
                this.LimparCampos();
                AtualizaGrid();

            }
            catch (Exception erro)
            {
                msg = "<script>ShowMsg('Vamos aprender','" + erro.Message + "');</script>";
                PlaceHolder1.Controls.Add(new LiteralControl(msg));
            }
        }
    }
}