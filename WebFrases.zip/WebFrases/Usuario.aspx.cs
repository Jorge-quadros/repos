﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebFrases.DAL;
using WebFrases.Modelo;

namespace WebFrases
{
    public partial class Usuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            AtualizaGrid();
        }

        protected void btCancelar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        public void AtualizaGrid()
        {
            DALUsuario dal = new DALUsuario();
            gvDados.DataSource = dal.Localizar();
            gvDados.DataBind();
        }

        private void LimparCampos()
        {
            txtID.Text = "";
            txtNome.Text = "";
            txtEmail.Text = "";
            txtSenha.Text = "";
            btSalvar.Text = "Inserir";
        }

        protected void btSalvar_Click(object sender, EventArgs e)
        {
            String msg = "";
            DALUsuario dal = new DALUsuario();
            ModeloUsuario obj = new ModeloUsuario();
            obj.Nome = txtNome.Text;
            obj.Email = txtEmail.Text;
            obj.Senha = txtSenha.Text;
            ModeloUsuario validaEmail = dal.GetRegistro(txtEmail.Text);

            try
            {
                if (btSalvar.Text == "Inserir")
                {

                    //Acessa o objeto DAL e Inseri os dados no Banco de Dados
                    //validação do email
                    if (validaEmail.id == 0)
                    {
                        dal.Inserir(obj);
                        msg = "<script> ShowMsg('Cadastro','O código gerado foi: '" + obj.id.ToString() + "'); </script>";
                        PlaceHolder1.Controls.Add(new LiteralControl(msg));
                    }
                    else
                    {
                        msg = "<script> ShowMsg('Cadastro','Não possível cadastrar o usuário, já existe um usuário cadastrado com esse e-mail.'); </script>";
                        PlaceHolder1.Controls.Add(new LiteralControl(msg));
                    }

                }
                else
                {
                    Boolean flag = true;//pode alterar
                    obj.id = Convert.ToInt32(txtID.Text);
                    //Acessa o objeto DAL e Altera os dados no Banco de Dados
                    //validação do email
                    if ((validaEmail.id!=0) &&(validaEmail.id != obj.id))
                    {
                        flag = false;
                        msg = "<script> ShowMsg('Cadastro','Não possível cadastrar o usuário, já existe um usuário cadastrado com esse e-mail.'); </script>";
                        PlaceHolder1.Controls.Add(new LiteralControl(msg));
                    }
                    else
                    {
                        dal.Alterar(obj);
                        msg = "<script> ShowMsg('Cadastro','Registro alterado corretamente!!!'); </script>";
                        PlaceHolder1.Controls.Add(new LiteralControl(msg));
                    }
                }

                Response.Write(msg);
                AtualizaGrid();

            }
            catch (Exception erro)
            {
                msg = "<script> ShowMsg('Cadastro','" + erro.Message + "'); </script>";
                PlaceHolder1.Controls.Add(new LiteralControl(msg));
            }
            this.LimparCampos();
        }

        protected void gvDados_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            int index = Convert.ToInt32(e.RowIndex);
            int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
            DALUsuario dal = new DALUsuario();
            dal.Excluir(cod);
            AtualizaGrid();

        }

        protected void gvDados_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int index = gvDados.SelectedIndex;
                int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
                DALUsuario dal = new DALUsuario();
                ModeloUsuario c = dal.GetRegistro(cod);
                if (c.id != 0)
                {
                    txtID.Text = c.id.ToString();
                    txtNome.Text = c.Nome;
                    txtEmail.Text = c.Email;
                    txtSenha.Text = c.Senha;
                    btSalvar.Text = "Alterar";
                }
            }
            catch
            {

            }
        }
    }
}