﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebFrases.DAL;
using WebFrases.Modelo;

namespace WebFrases
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private System.Configuration.ConnectionStringSettings connString;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Atualiza o grid
            AtualizaGrid();
        }

        public void AtualizaGrid()
        {
            DALCategoria dal = new DALCategoria();
            gvDados.DataSource = dal.Localizar();
            gvDados.DataBind();
        }

        private void LimparCampos()
        {
            txtID.Text = "";
            txtNome.Text = "";
            btSalvar.Text = "Inserir";
        }

        protected void btSalvar_Click(object sender, EventArgs e)
        {

            String msg = "";
            DALCategoria dal = new DALCategoria();
            ModeloCategoria obj = new ModeloCategoria();
            obj.Nome = txtNome.Text;

            try
            {
                if (btSalvar.Text == "Inserir")
                {

                    //Acessa o objeto DAL e Inseri os dados no Banco de Dados
                    dal.Inserir(obj);
                    msg = "<script>alert('O código gerado foi: '" + obj.Id.ToString() + "');</script>";
                    PlaceHolder1.Controls.Add(new LiteralControl(msg));
                }
                else
                {

                    //Acessa o objeto DAL e Altera os dados no Banco de Dados
                    obj.Id = Convert.ToInt32(txtID.Text);
                    dal.Alterar(obj);
                    msg = "<script>alert('Registro alterado corretamente!!!');</script>";
                    PlaceHolder1.Controls.Add(new LiteralControl(msg));
                }

                Response.Write(msg);
                this.LimparCampos();
                AtualizaGrid();

            }
            catch(Exception erro)
            {
                //
                msg = "<script>alert('" + erro.Message + "');</script>";
                PlaceHolder1.Controls.Add(new LiteralControl(msg));
            }

        }

        protected void btCancelar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        protected void gvDados_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            

            int index = Convert.ToInt32(e.RowIndex);
            int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
            DALCategoria dal = new DALCategoria();

            System.Configuration.Configuration rootWebConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/MyWebSiteRoot");
            connString = rootWebConfig.ConnectionStrings.ConnectionStrings["sisfrases9ConnectionString"];

            SqlConnection Consulta = new SqlConnection();
            Consulta.ConnectionString = connString.ToString();
            SqlCommand CmdConsulta = new SqlCommand();
            String msg = "";
                        
            CmdConsulta.Connection = Consulta;
            CmdConsulta.CommandText = "Select * from frases where categoria=@categoria";
            CmdConsulta.Parameters.AddWithValue("categoria", cod.ToString());

            Consulta.Open();

            SqlDataReader registro = CmdConsulta.ExecuteReader();

            if (registro.HasRows == false)
            {
                dal.Excluir(cod);
            }
            else
            {
                 msg = "<script> ShowMsg('Cadastro','Registro não pode ser excluido pois está vinculado em outras tabelas!!'); </script>";
                PlaceHolder1.Controls.Add(new LiteralControl(msg));
            }
        }
        
        protected void gvDados_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int index = gvDados.SelectedIndex;
                int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
                DALCategoria dal = new DALCategoria();
                ModeloCategoria c = dal.GetRegistro(cod);
                if (c.Id != 0)
                {
                    txtID.Text = c.Id.ToString();
                    txtNome.Text = c.Nome;
                    btSalvar.Text = "Alterar";
                }
            }
            catch
            {

            }
        }
    }
}