﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebFrases.DAL;
using WebFrases.Modelo;

namespace WebFrases
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] != null)
            {
                DALUsuario du = new DALUsuario();
                ModeloUsuario u = du.GetRegistro(Session["email"].ToString());
                lbNome.Text = u.Nome;
                lbNome.Text = u.Email;
                
            }
        }
    }
}