﻿namespace WebFrases.DAL
{
    public class ModeloAutor
    {
    }
}