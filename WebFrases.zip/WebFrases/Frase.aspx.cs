﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebFrases.DAL;
using WebFrases.Modelo;

namespace WebFrases
{
    public partial class Frase : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            AtualizaGrid();
            if (!IsPostBack)
            {
                AtualizaAutor();
                AtualizaCategoria();
            }
        }

        public void AtualizaGrid()
        {
            DALFrase dal = new DALFrase();
            gvDados.DataSource = dal.Localizar();
            gvDados.DataBind();
        }

        public void AtualizaAutor()
        {
            DALAutor dal = new DALAutor();
            ddlAutor.DataSource = dal.Localizar();
            ddlAutor.DataTextField = "Nome";
            ddlAutor.DataValueField = "id";
            ddlAutor.DataBind();
        }

        public void AtualizaCategoria()
        {
            
            DALCategoria dal = new DALCategoria();
            ddlCategoria.DataSource = dal.Localizar();
            ddlCategoria.DataTextField = "categoria";
            ddlCategoria.DataValueField = "id";
            ddlCategoria.DataBind();
        }

        private void LimparCampos()
        {
            txtID.Text = "";
            txtFrase.Text = "";
            btSalvar.Text = "Inserir";
        }

        protected void btCancelar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        protected void btSalvar_Click(object sender, EventArgs e)
        {
            String msg = "";
            DALFrase dal = new DALFrase();
            ModeloFrases obj = new ModeloFrases();
            obj.Texto = txtFrase.Text;
            obj.Autor =Convert.ToInt32(ddlAutor.SelectedValue);
            obj.Categoria = Convert.ToInt32(ddlCategoria.SelectedValue);

            try
            {
                if (btSalvar.Text == "Inserir")
                {

                    //Acessa o objeto DAL e Inseri os dados no Banco de Dados
                    dal.Inserir(obj);
                    msg = "<script> ShowMsg('Cadastro','O código gerado foi: '" + obj.id.ToString() + "'); </script>";
                    PlaceHolder1.Controls.Add(new LiteralControl(msg));
                }
                else
                {

                    //Acessa o objeto DAL e Altera os dados no Banco de Dados
                    obj.id = Convert.ToInt32(txtID.Text);
                    dal.Alterar(obj);
                    
                    msg = "<script> ShowMsg('Cadastro','Registro alterado corretamente!!!'); </script>";
                    PlaceHolder1.Controls.Add(new LiteralControl(msg));

                }

                Response.Write(msg);
                this.LimparCampos();
                AtualizaGrid();

            }
            catch (Exception erro)
            {
                //
                msg = "<script> ShowMsg('Cadastro','" + erro.Message + "'); </script>";
                PlaceHolder1.Controls.Add(new LiteralControl(msg));
            }
        }

        protected void gvDados_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int index = gvDados.SelectedIndex;
                int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
                DALFrase dal = new DALFrase();
                ModeloFrases f = dal.GetRegistro(cod);
                if (f.id != 0)
                {
                    txtID.Text = f.id.ToString();
                    txtFrase.Text = f.Texto;
                    ddlAutor.SelectedValue = f.Autor.ToString();
                    ddlCategoria.SelectedValue = f.Categoria.ToString();
                    btSalvar.Text = "Alterar";
                }
            }
            catch
            {

            }
        }

        protected void gvDados_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt32(e.RowIndex);
            int cod = Convert.ToInt32(gvDados.Rows[index].Cells[2].Text);
            DALFrase dal = new DALFrase();
            dal.Excluir(cod);
            AtualizaGrid();
        }
    }
}